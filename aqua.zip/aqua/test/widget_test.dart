import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:aqua/main.dart';

void main() {
  testWidgets('AquaSenseApp navigation flow test', (WidgetTester tester) async {
    // Build the app and trigger a frame
    await tester.pumpWidget(const AquaSenseApp());

    // Verify that the app starts on the SplashScreen
    expect(find.text('AquaSense'), findsOneWidget);

    // Simulate the splash screen delay (4 seconds) and navigate to LoginScreen
    await tester.pump(const Duration(seconds: 4));
    await tester.pumpAndSettle(); // Wait for navigation to complete

    // Verify that we're now on the LoginScreen
    expect(find.text('Log in'), findsOneWidget);
    expect(find.text('Sign up'), findsOneWidget);

    // Verify that the "Log in" tab is selected by default
    expect(
      find.byWidgetPredicate((widget) =>
      widget is Text &&
          widget.data == 'Log in' &&
          widget.style?.color == Colors.blue[700]),
      findsOneWidget,
    );

    // Tap the "Sign up" tab and verify the sign-up form is displayed
    await tester.tap(find.text('Sign up'));
    await tester.pumpAndSettle();

    expect(
      find.byWidgetPredicate((widget) =>
      widget is Text &&
          widget.data == 'Sign up' &&
          widget.style?.color == Colors.blue[700]),
      findsOneWidget,
    );
    expect(find.text('NAME'), findsOneWidget);
    expect(find.text('EMAIL'), findsOneWidget);
    expect(find.text('CREATE A PASSWORD'), findsOneWidget);
    expect(find.text('CONFIRM PASSWORD'), findsOneWidget);

    // Fill out the sign-up form
    await tester.enterText(find.widgetWithText(TextFormField, 'enter your full name'), 'Jonel Larga');
    await tester.enterText(find.widgetWithText(TextFormField, 'example@gmail.com'), 'qjelarga@tip.edu.ph');
    await tester.enterText(find.widgetWithText(TextFormField, 'must be 8 characters'), 'password123');
    await tester.enterText(find.widgetWithText(TextFormField, 'repeat password'), 'password123');

    // Tap the "Sign up" button and navigate to MainScreen
    await tester.tap(find.widgetWithText(ElevatedButton, 'Sign up'));
    await tester.pumpAndSettle();

    // Verify that we're now on the MainScreen (HomeScreen by default)
    expect(find.text('Control Panel'), findsOneWidget);
    expect(find.text('Start Analysis'), findsOneWidget);

    // Verify the bottom navigation bar is present
    expect(find.text('Home'), findsOneWidget);
    expect(find.text('History'), findsOneWidget);
    expect(find.text('User'), findsOneWidget);
    expect(find.text('Help'), findsOneWidget);

    // Tap the "Start Analysis" button and verify the snackbar
    await tester.tap(find.text('Start Analysis'));
    await tester.pump();
    expect(find.text('Starting Analysis...'), findsOneWidget);
  });
}