package com.example.aqua

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
