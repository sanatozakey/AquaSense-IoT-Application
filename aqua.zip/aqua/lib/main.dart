import 'package:flutter/material.dart';
import 'screens/splash_screen.dart';

void main() {
  runApp(const AquaSenseApp());
}

class AquaSenseApp extends StatelessWidget {
  const AquaSenseApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: const SplashScreen(), // Set SplashScreen as the initial screen
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
    );
  }
}