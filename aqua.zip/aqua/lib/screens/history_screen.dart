import 'package:flutter/material.dart';

class WaterTestRecord {
  final String dateTime;
  final double pH;
  final double turbidity;
  final String status;

  const WaterTestRecord({
    required this.dateTime,
    required this.pH,
    required this.turbidity,
    required this.status,
  });
}

class HistoryScreen extends StatelessWidget {
  const HistoryScreen({Key? key}) : super(key: key);

  // Sample data for the history table
  static const List<WaterTestRecord> _records = [
    WaterTestRecord(
      dateTime: "3/29/25 10:25 AM",
      pH: 7.2,
      turbidity: 1.3,
      status: "Safe",
    ),
    WaterTestRecord(
      dateTime: "3/28/25 10:40 AM",
      pH: 8.0,
      turbidity: 380.0,
      status: "Unsafe",
    ),
    WaterTestRecord(
      dateTime: "3/27/25 12:30 PM",
      pH: 5.5,
      turbidity: 5.0,
      status: "Unsafe",
    ),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        width: MediaQuery.of(context).size.width,
        height: MediaQuery.of(context).size.height,
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              Colors.blue[50]!,
              Colors.blue[100]!,
            ],
          ),
        ),
        child: SafeArea(
          child: Column(
            children: [
              // Logo
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 20.0),
                child: Container(
                  width: 100,
                  height: 100,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: LinearGradient(
                      colors: [
                        Colors.blue[800]!,
                        Colors.blue[900]!,
                        Colors.blue[700]!,
                      ],
                      begin: Alignment.topCenter,
                      end: Alignment.bottomCenter,
                    ),
                  ),
                  child: const Center(
                    child: Text(
                      'AquaSense',
                      style: TextStyle(
                        fontSize: 14,
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                        shadows: [
                          Shadow(
                            blurRadius: 4.0,
                            color: Colors.black87,
                            offset: Offset(1, 1),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
              // Title
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 10.0),
                child: Text(
                  'HISTORY',
                  style: TextStyle(
                    fontSize: 24,
                    fontWeight: FontWeight.bold,
                    color: Colors.blue[800],
                  ),
                ),
              ),
              // History Table
              Expanded(
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 20.0, vertical: 10.0),
                  child: SingleChildScrollView(
                    scrollDirection: Axis.vertical,
                    child: Container(
                      decoration: BoxDecoration(
                        border: Border.all(color: Colors.blue[600]!, width: 2),
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: DataTable(
                        columnSpacing: 10,
                        headingRowColor: MaterialStateColor.resolveWith((states) => Colors.blue[50]!),
                        dataRowColor: MaterialStateColor.resolveWith((states) {
                          return states.contains(MaterialState.selected)
                              ? Colors.blue[100]!
                              : Colors.white;
                        }),
                        columns: [
                          DataColumn(
                            label: Text(
                              'Date/Time',
                              style: TextStyle(
                                fontSize: 14,
                                fontWeight: FontWeight.bold,
                                color: Colors.blue[800],
                              ),
                            ),
                          ),
                          DataColumn(
                            label: Text(
                              'pH/Turbidity',
                              style: TextStyle(
                                fontSize: 14,
                                fontWeight: FontWeight.bold,
                                color: Colors.blue[800],
                              ),
                            ),
                          ),
                          DataColumn(
                            label: Text(
                              'Status',
                              style: TextStyle(
                                fontSize: 14,
                                fontWeight: FontWeight.bold,
                                color: Colors.blue[800],
                              ),
                            ),
                          ),
                        ],
                        rows: List.generate(
                          _records.length,
                              (index) {
                            final record = _records[index];
                            return DataRow(
                              color: MaterialStateColor.resolveWith((states) {
                                return index % 2 == 0 ? Colors.white : Colors.blue[50]!;
                              }),
                              cells: [
                                DataCell(
                                  Text(
                                    record.dateTime,
                                    style: const TextStyle(fontSize: 12),
                                  ),
                                ),
                                DataCell(
                                  Text(
                                    'pH: ${record.pH.toStringAsFixed(1)} / Turbidity: ${record.turbidity.toStringAsFixed(1)}',
                                    style: const TextStyle(fontSize: 12),
                                  ),
                                ),
                                DataCell(
                                  Text(
                                    record.status,
                                    style: TextStyle(
                                      fontSize: 12,
                                      color: record.status == "Safe" ? Colors.green : Colors.red,
                                      fontWeight: FontWeight.w500,
                                    ),
                                  ),
                                ),
                              ],
                            );
                          },
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}