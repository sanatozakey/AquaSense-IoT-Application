import 'package:flutter/material.dart';
import 'home_screen.dart';
import 'history_screen.dart';
import 'help_screen.dart';
import 'user_screen.dart';

class MainScreen extends StatefulWidget {
  final String? userName;
  final String? userEmail;

  const MainScreen({Key? key, this.userName, this.userEmail}) : super(key: key);

  @override
  MainScreenState createState() => MainScreenState();
}

class MainScreenState extends State<MainScreen> {
  int _selectedIndex = 0; // Start on the "Home" tab

  late final List<Widget> _screens;

  @override
  void initState() {
    super.initState();
    _screens = [
      const HomeScreen(), // Home tab
      const HistoryScreen(), // History tab
      UserScreen(
        userName: widget.userName ?? 'Jonel Larga',
        userEmail: widget.userEmail ?? 'qjelarga@tip.edu.ph',
      ), // User tab
      const HelpScreen(), // Help tab
    ];
  }

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: _screens[_selectedIndex],
      bottomNavigationBar: BottomNavigationBar(
        items: const <BottomNavigationBarItem>[
          BottomNavigationBarItem(
            icon: Icon(Icons.home),
            label: 'Home',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.history),
            label: 'History',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.person),
            label: 'User',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.help),
            label: 'Help',
          ),
        ],
        currentIndex: _selectedIndex,
        selectedItemColor: Colors.blue,
        unselectedItemColor: Colors.grey,
        onTap: _onItemTapped,
      ),
    );
  }
}