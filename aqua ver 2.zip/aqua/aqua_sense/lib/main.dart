import 'package:flutter/material.dart';
import 'screens/splash_screen.dart';
import 'screens/login_screen.dart';
import 'screens/main_screen.dart';
import '../services/web_serial.dart';

void main() {
  runApp(const MyApp());
}

class AppState extends InheritedWidget {
  final WebSerial webSerial;

  const AppState({
    super.key,
    required this.webSerial,
    required super.child,
  });

  static AppState? of(BuildContext context) {
    return context.dependOnInheritedWidgetOfExactType<AppState>();
  }

  @override
  bool updateShouldNotify(AppState oldWidget) => false;
}

class MyApp extends StatefulWidget {
  const MyApp({super.key});

  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  late final WebSerial _webSerial;

  @override
  void initState() {
    super.initState();
    _webSerial = WebSerial();
    _webSerial.connect();
  }

  @override
  void dispose() {
    _webSerial.disconnect();
    _webSerial.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AppState(
      webSerial: _webSerial,
      child: MaterialApp(
        title: 'AquaSense',
        theme: ThemeData(
          primarySwatch: Colors.blue,
        ),
        home: const SplashScreen(),
        routes: {
          '/login': (context) => const LoginScreen(),
          '/main': (context) => MainScreen(
                webSerial: AppState.of(context)!.webSerial,
              ),
        },
      ),
    );
  }
}