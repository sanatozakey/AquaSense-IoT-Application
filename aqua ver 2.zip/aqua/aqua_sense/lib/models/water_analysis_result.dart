class WaterAnalysisResult {
  final DateTime dateTime;
  final double pH;
  final String status;

  const WaterAnalysisResult({
    required this.dateTime,
    required this.pH,
    required this.status,
  });
}