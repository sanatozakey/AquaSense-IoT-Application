import 'package:flutter/material.dart';
import '../widgets/aqua_sense_logo.dart';

class HelpScreen extends StatelessWidget {
  const HelpScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: MediaQuery.of(context).size.width,
      height: MediaQuery.of(context).size.height,
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [
            Colors.blue[50]!,
            Colors.blue[100]!,
          ],
        ),
      ),
      child: SafeArea(
        child: Column(
          children: [
            const Padding(
              padding: EdgeInsets.symmetric(vertical: 20.0),
              child: AquaSenseLogo(),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 10.0),
              child: Text(
                'Help',
                style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                  color: Colors.blue[800],
                ),
              ),
            ),
            Expanded(
              child: ListView(
                children: const [
                  ExpansionTile(
                    title: Text('How can I use the app?'),
                    children: [
                      Padding(
                        padding: EdgeInsets.all(16.0),
                        child: Text(
                          'To use the app, log in with your email and password. Navigate through the Home, History, User, and Help tabs to access different kullanım özellikleri.',
                        ),
                      ),
                    ],
                  ),
                  ExpansionTile(
                    title: Text('Do I need a student ID to login?'),
                    children: [
                      Padding(
                        padding: EdgeInsets.all(16.0),
                        child: Text(
                          'No, you do not need a student ID to log in. You can use your email and password to access the app.',
                        ),
                      ),
                    ],
                  ),
                  ExpansionTile(
                    title: Text('How do I determine the readings?'),
                    children: [
                      Padding(
                        padding: EdgeInsets.all(16.0),
                        child: Text(
                          'The readings are determined automatically by the device once it is connected. You can view them in the History tab.',
                        ),
                      ),
                    ],
                  ),
                  ExpansionTile(
                    title: Text('Can the readings be downloaded?'),
                    children: [
                      Padding(
                        padding: EdgeInsets.all(16.0),
                        child: Text(
                          'Yes, you can download the readings from the History tab by selecting the export option.',
                        ),
                      ),
                    ],
                  ),
                  ExpansionTile(
                    title: Text('How long does it take to analyze the readings?'),
                    children: [
                      Padding(
                        padding: EdgeInsets.all(16.0),
                        child: Text(
                          'The analysis duration depends on the amount of data. Typically, it takes a few seconds to a minute.',
                        ),
                      ),
                    ],
                  ),
                  ExpansionTile(
                    title: Text('How long do I wait for the device to connect?'),
                    children: [
                      Padding(
                        padding: EdgeInsets.all(16.0),
                        child: Text(
                          'The device usually connects within 10-30 seconds, depending on your browser and device status.',
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}