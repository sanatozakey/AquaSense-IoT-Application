import 'package:flutter/material.dart';
import '../screens/result_screen.dart';
import '../models/water_analysis_result.dart';
import '../services/web_serial.dart';

class HistoryScreen extends StatefulWidget {
  final WebSerial webSerial; // Added webSerial parameter

  const HistoryScreen({super.key, required this.webSerial});

  @override
  HistoryScreenState createState() => HistoryScreenState();
}

class HistoryScreenState extends State<HistoryScreen> {
  static List<WaterAnalysisResult> _records = [];

  static void addRecord(WaterAnalysisResult result) {
    _records.insert(0, result);
  }

  int _selectedIndex = 1; // Default to History tab
  final List<String> _appBarTitles = ['Home', 'History', 'Analysis'];

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
    if (index == 0) {
      Navigator.pushReplacementNamed(context, '/main'); // Assumes /main is MainScreen
    } else if (index == 2) {
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) => ResultScreen(
            webSerial: widget.webSerial, // Pass webSerial
          ),
        ),
      );
    }
  }

  String _formatDateTime(DateTime dateTime) {
    final hour = dateTime.hour % 12 == 0 ? 12 : dateTime.hour % 12;
    final minute = dateTime.minute.toString().padLeft(2, '0');
    final period = dateTime.hour < 12 ? 'AM' : 'PM';
    return '${dateTime.month}/${dateTime.day}/${dateTime.year % 100} $hour:$minute $period';
  }

  @override
  Widget build(BuildContext context) {
    double screenWidth = MediaQuery.of(context).size.width;
    double maxContentWidth = 600; // Wider max width for table
    double padding = screenWidth * 0.05; // 5% of screen width for padding

    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () {
            Navigator.pop(context);
          },
        ),
        title: Text(
          _appBarTitles[_selectedIndex],
          style: TextStyle(
            fontSize: screenWidth * 0.06 > 24 ? 24 : screenWidth * 0.06,
            fontWeight: FontWeight.bold,
            color: Colors.blue[800],
          ),
        ),
        backgroundColor: Colors.transparent,
        elevation: 0,
      ),
      body: Container(
        width: screenWidth,
        height: MediaQuery.of(context).size.height,
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              Colors.blue[50]!,
              Colors.blue[100]!,
            ],
          ),
        ),
        child: SafeArea(
          child: Center(
            child: SizedBox(
              width: screenWidth > maxContentWidth ? maxContentWidth : screenWidth * 0.9,
              child: Column(
                children: [
                  Expanded(
                    child: SingleChildScrollView(
                      scrollDirection: Axis.vertical,
                      child: Container(
                        margin: EdgeInsets.symmetric(vertical: padding),
                        decoration: BoxDecoration(
                          border: Border.all(color: Colors.blue[600]!, width: 2),
                          borderRadius: BorderRadius.circular(screenWidth * 0.025),
                        ),
                        child: DataTable(
                          columnSpacing: screenWidth * 0.02,
                          headingRowColor: WidgetStateColor.resolveWith((states) => Colors.blue[50]!),
                          dataRowColor: WidgetStateColor.resolveWith((states) {
                            return states.contains(WidgetState.selected)
                                ? Colors.blue[100]!
                                : Colors.white;
                          }),
                          columns: [
                            DataColumn(
                              label: Text(
                                'Date/Time',
                                style: TextStyle(
                                  fontSize: screenWidth * 0.035 > 14 ? 14 : screenWidth * 0.035,
                                  fontWeight: FontWeight.bold,
                                  color: Colors.blue[800],
                                ),
                              ),
                            ),
                            DataColumn(
                              label: Text(
                                'pH',
                                style: TextStyle(
                                  fontSize: screenWidth * 0.035 > 14 ? 14 : screenWidth * 0.035,
                                  fontWeight: FontWeight.bold,
                                  color: Colors.blue[800],
                                ),
                              ),
                            ),
                            DataColumn(
                              label: Text(
                                'Status',
                                style: TextStyle(
                                  fontSize: screenWidth * 0.035 > 14 ? 14 : screenWidth * 0.035,
                                  fontWeight: FontWeight.bold,
                                  color: Colors.blue[800],
                                ),
                              ),
                            ),
                          ],
                          rows: List.generate(
                            _records.length,
                            (index) {
                              final record = _records[index];
                              return DataRow(
                                color: WidgetStateColor.resolveWith((states) {
                                  return index % 2 == 0 ? Colors.white : Colors.blue[50]!;
                                }),
                                cells: [
                                  DataCell(
                                    Text(
                                      _formatDateTime(record.dateTime),
                                      style: TextStyle(fontSize: screenWidth * 0.03 > 12 ? 12 : screenWidth * 0.03),
                                    ),
                                  ),
                                  DataCell(
                                    Text(
                                      record.pH.toStringAsFixed(1),
                                      style: TextStyle(fontSize: screenWidth * 0.03 > 12 ? 12 : screenWidth * 0.03),
                                    ),
                                  ),
                                  DataCell(
                                    Text(
                                      record.status,
                                      style: TextStyle(
                                        fontSize: screenWidth * 0.03 > 12 ? 12 : screenWidth * 0.03,
                                        color: record.status == "Safe" ? Colors.green : Colors.red,
                                        fontWeight: FontWeight.w500,
                                      ),
                                    ),
                                  ),
                                ],
                              );
                            },
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
      bottomNavigationBar: BottomNavigationBar(
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.home), label: 'Home'),
          BottomNavigationBarItem(icon: Icon(Icons.history), label: 'History'),
          BottomNavigationBarItem(icon: Icon(Icons.analytics), label: 'Analysis'),
        ],
        currentIndex: _selectedIndex,
        selectedItemColor: Colors.blue[600],
        onTap: _onItemTapped,
      ),
    );
  }
}