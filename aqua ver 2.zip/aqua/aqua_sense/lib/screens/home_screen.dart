import 'package:flutter/material.dart';
import 'dart:convert';
import 'result_screen.dart';
import '../widgets/aqua_sense_logo.dart';
import 'history_screen.dart';
import '../services/web_serial.dart';
import '../models/water_analysis_result.dart';
import 'dart:async';
import 'dart:js_interop';

class HomePage extends StatefulWidget {
  final WebSerial webSerial;

  const HomePage({super.key, required this.webSerial});

  @override
  HomePageState createState() => HomePageState();
}

class HomePageState extends State<HomePage> with TickerProviderStateMixin {
  double _pH = 7.2;
  String _status = 'Unknown';
  StreamSubscription<String>? _dataSubscription;
  StreamSubscription<bool>? _connectionSubscription;
  bool _showNotification = false;
  bool _needsCalibration = false;
  bool _showManualCalibration = false;
  bool _isCalibrated = false;
  String _calibrationStep = 'none';
  late AnimationController _notificationController;
  late Animation<Offset> _notificationAnimation;
  String _notificationMessage = '';

  @override
  void initState() {
    super.initState();
    _notificationController = AnimationController(
      duration: const Duration(milliseconds: 500),
      vsync: this,
    );
    _notificationAnimation = Tween<Offset>(
      begin: const Offset(0, 1),
      end: Offset.zero,
    ).animate(CurvedAnimation(
      parent: _notificationController,
      curve: Curves.easeOut,
    ));

    widget.webSerial.connect();

    _connectionSubscription = widget.webSerial.getConnectionStatus().listen((isConnected) {
      setState(() {
        _showNotification = true;
        _notificationMessage = isConnected ? 'Device Connected Successfully' : 'Failed to Connect Device';
        _notificationController.forward(from: 0.0);
      });
      debugPrint('Connection status changed: $isConnected at ${DateTime.now()}');
    });

    _dataSubscription = widget.webSerial.getDataStream().listen(
      (data) {
        debugPrint('Received data from Arduino: $data at ${DateTime.now()}');
        if (data.contains("DATA:")) {
          String jsonStr = data.split("DATA:")[1].trim();
          try {
            Map<String, dynamic> jsonData = jsonDecode(jsonStr);
            setState(() {
              _pH = double.parse(jsonData['pH'].toString());
              _status = (_pH >= 6.5 && _pH <= 8.5) ? 'Safe' : 'Unsafe';
              _needsCalibration = _pH < 0 || _pH > 14 || _status == 'Unknown';
              if (_needsCalibration) {
                _isCalibrated = false;
                _calibrationStep = 'none';
                _showManualCalibration = false;
              } else if (_showManualCalibration) {
                _showManualCalibration = false;
              }
              final dateTime = DateTime.now();
              final result = WaterAnalysisResult(
                dateTime: dateTime,
                pH: _pH,
                status: _status,
              );
              HistoryScreenState.addRecord(result);
            });
          } catch (error) {
            debugPrint('Error parsing pH data: $error at ${DateTime.now()}');
            setState(() {
              _needsCalibration = true;
              _isCalibrated = false;
              _calibrationStep = 'none';
            });
          }
        }
      },
      onError: (error) {
        debugPrint('WebSocket stream error: $error at ${DateTime.now()}');
        setState(() {
          _needsCalibration = true;
          _isCalibrated = false;
          _calibrationStep = 'none';
        });
      },
      onDone: () {
        debugPrint('WebSocket connection closed at ${DateTime.now()}');
        setState(() {
          _pH = 7.2;
          _status = 'Unknown';
          _needsCalibration = false;
          _showManualCalibration = false;
          _isCalibrated = false;
          _calibrationStep = 'none';
          _showNotification = true;
          _notificationMessage = 'Failed to Connect Device';
          _notificationController.forward(from: 0.0);
        });
      },
    );
  }

  @override
  void dispose() {
    _dataSubscription?.cancel();
    _connectionSubscription?.cancel();
    _notificationController.dispose();
    super.dispose();
  }

  void _startAnalysis() {
    if (widget.webSerial.isConnected) {
      debugPrint('Sending START_ANALYSIS command at ${DateTime.now()}');
      widget.webSerial.socket!.send('START_ANALYSIS'.toJS);
    } else {
      debugPrint('Cannot start analysis: Not connected at ${DateTime.now()}');
    }
  }

  void _sendCalibrationCommand(String command) {
    if (!widget.webSerial.isConnected) {
      debugPrint('Cannot send $command: Not connected at ${DateTime.now()}');
      return;
    }

    bool canProceed = false;
    String message = '';

    if (command == 'enterph' && _calibrationStep == 'none') {
      canProceed = true;
      _calibrationStep = 'enterph';
      message = 'Submerge probe in pH 7.00 buffer, then press "calph".';
    } else if (command == 'calph' && _calibrationStep == 'enterph') {
      canProceed = true;
      _calibrationStep = 'calph';
      message = 'Submerge probe in pH 4.00 buffer, then press "exitph".';
    } else if (command == 'exitph' && _calibrationStep == 'calph') {
      canProceed = true;
      _calibrationStep = 'none';
      _isCalibrated = true;
      message = 'Calibration completed. Ready to start analysis.';
    } else {
      message = 'Incorrect calibration step. Start with "enterph".';
    }

    if (canProceed) {
      debugPrint('Sending $command command at ${DateTime.now()}');
      widget.webSerial.socket!.send(command.toJS);
    }

    setState(() {
      _showNotification = true;
      _notificationMessage = message;
      _notificationController.forward(from: 0.0);
    });
  }

  void _navigateToResultScreen() {
    final dateTime = DateTime.now();
    final result = WaterAnalysisResult(
      dateTime: dateTime,
      pH: _pH,
      status: _status,
    );
    HistoryScreenState.addRecord(result);
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => ResultScreen(
          webSerial: widget.webSerial,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    double screenWidth = MediaQuery.of(context).size.width;
    double maxContentWidth = 400;
    double padding = screenWidth * 0.05;

    return Scaffold(
      body: Container(
        width: screenWidth,
        height: MediaQuery.of(context).size.height,
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              Colors.blue[50]!,
              Colors.blue[100]!,
            ],
          ),
        ),
        child: SafeArea(
          child: Stack(
            children: [
              SingleChildScrollView( // Added SingleChildScrollView to handle overflow
                child: Center(
                  child: SizedBox(
                    width: screenWidth > maxContentWidth ? maxContentWidth : screenWidth * 0.9,
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Padding(
                          padding: EdgeInsets.symmetric(vertical: padding),
                          child: const AquaSenseLogo(),
                        ),
                        Padding(
                          padding: EdgeInsets.symmetric(vertical: padding),
                          child: Text(
                            'HOME',
                            style: TextStyle(
                              fontSize: screenWidth * 0.06 > 24 ? 24 : screenWidth * 0.06,
                              fontWeight: FontWeight.bold,
                              color: Colors.blue[800],
                            ),
                          ),
                        ),
                        StreamBuilder<bool>(
                          stream: widget.webSerial.getConnectionStatus(),
                          initialData: false,
                          builder: (context, snapshot) {
                            bool isConnected = snapshot.data ?? false;
                            return Padding(
                              padding: EdgeInsets.symmetric(vertical: padding * 0.5),
                              child: Text(
                                isConnected ? 'Connected to Arduino Sensor' : 'Not Connected to Arduino Sensor',
                                style: TextStyle(
                                  fontSize: screenWidth * 0.04 > 16 ? 16 : screenWidth * 0.04,
                                  color: isConnected ? Colors.green : Colors.red[700],
                                  fontWeight: FontWeight.w500,
                                ),
                              ),
                            );
                          },
                        ),
                        if (_needsCalibration && widget.webSerial.isConnected && !_showManualCalibration) ...[
                          Padding(
                            padding: EdgeInsets.symmetric(vertical: padding * 0.5),
                            child: Text(
                              'Calibration Needed',
                              style: TextStyle(
                                fontSize: screenWidth * 0.04 > 16 ? 16 : screenWidth * 0.04,
                                color: Colors.orange[700],
                                fontWeight: FontWeight.w500,
                              ),
                            ),
                          ),
                        ],
                        if (_showManualCalibration && widget.webSerial.isConnected) ...[
                          Padding(
                            padding: EdgeInsets.symmetric(vertical: padding * 0.5),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Padding(
                                  padding: EdgeInsets.symmetric(horizontal: padding * 0.2),
                                  child: Tooltip(
                                    message: 'Start calibration with pH 7.00 buffer.',
                                    child: ElevatedButton(
                                      onPressed: () => _sendCalibrationCommand('enterph'),
                                      style: ElevatedButton.styleFrom(
                                        backgroundColor: Colors.orange[600],
                                        foregroundColor: Colors.white,
                                        padding: EdgeInsets.symmetric(
                                          horizontal: screenWidth * 0.03,
                                          vertical: screenWidth * 0.015,
                                        ),
                                        shape: RoundedRectangleBorder(
                                          borderRadius: BorderRadius.circular(screenWidth * 0.02),
                                        ),
                                        elevation: 5,
                                        textStyle: TextStyle(
                                          fontSize: screenWidth * 0.03 > 12 ? 12 : screenWidth * 0.03,
                                        ),
                                      ),
                                      child: const Text('enterph'),
                                    ),
                                  ),
                                ),
                                Padding(
                                  padding: EdgeInsets.symmetric(horizontal: padding * 0.2),
                                  child: Tooltip(
                                    message: 'Calibrate with pH 4.00 buffer.',
                                    child: ElevatedButton(
                                      onPressed: () => _sendCalibrationCommand('calph'),
                                      style: ElevatedButton.styleFrom(
                                        backgroundColor: Colors.orange[600],
                                        foregroundColor: Colors.white,
                                        padding: EdgeInsets.symmetric(
                                          horizontal: screenWidth * 0.03,
                                          vertical: screenWidth * 0.015,
                                        ),
                                        shape: RoundedRectangleBorder(
                                          borderRadius: BorderRadius.circular(screenWidth * 0.02),
                                        ),
                                        elevation: 5,
                                        textStyle: TextStyle(
                                          fontSize: screenWidth * 0.03 > 12 ? 12 : screenWidth * 0.03,
                                        ),
                                      ),
                                      child: const Text('calph'),
                                    ),
                                  ),
                                ),
                                Padding(
                                  padding: EdgeInsets.symmetric(horizontal: padding * 0.2),
                                  child: Tooltip(
                                    message: 'Save calibration and exit.',
                                    child: ElevatedButton(
                                      onPressed: () => _sendCalibrationCommand('exitph'),
                                      style: ElevatedButton.styleFrom(
                                        backgroundColor: Colors.orange[600],
                                        foregroundColor: Colors.white,
                                        padding: EdgeInsets.symmetric(
                                          horizontal: screenWidth * 0.03,
                                          vertical: screenWidth * 0.015,
                                        ),
                                        shape: RoundedRectangleBorder(
                                          borderRadius: BorderRadius.circular(screenWidth * 0.02),
                                        ),
                                        elevation: 5,
                                        textStyle: TextStyle(
                                          fontSize: screenWidth * 0.03 > 12 ? 12 : screenWidth * 0.03,
                                        ),
                                      ),
                                      child: const Text('exitph'),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                        Padding(
                          padding: EdgeInsets.symmetric(vertical: padding),
                          child: ElevatedButton(
                            onPressed: () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(builder: (context) => HistoryScreen(webSerial: widget.webSerial)),
                              );
                            },
                            style: ElevatedButton.styleFrom(
                              backgroundColor: Colors.blue[600],
                              foregroundColor: Colors.white,
                              padding: EdgeInsets.symmetric(
                                horizontal: screenWidth * 0.08,
                                vertical: screenWidth * 0.03,
                              ),
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(screenWidth * 0.025),
                              ),
                              elevation: 5,
                              textStyle: TextStyle(
                                fontSize: screenWidth * 0.045 > 18 ? 18 : screenWidth * 0.045,
                              ),
                            ),
                            child: const Text('View History'),
                          ),
                        ),
                        if (widget.webSerial.isConnected && !_isCalibrated && !_needsCalibration) ...[
                          Padding(
                            padding: EdgeInsets.symmetric(vertical: padding * 0.5),
                            child: Text(
                              'Calibration Recommended',
                              style: TextStyle(
                                fontSize: screenWidth * 0.035 > 14 ? 14 : screenWidth * 0.035,
                                color: Colors.orange[700],
                                fontWeight: FontWeight.w500,
                              ),
                            ),
                          ),
                        ],
                        Padding(
                          padding: EdgeInsets.symmetric(vertical: padding),
                          child: ElevatedButton(
                            onPressed: widget.webSerial.isConnected
                                ? () {
                                    _startAnalysis();
                                    _navigateToResultScreen();
                                  }
                                : null,
                            style: ElevatedButton.styleFrom(
                              backgroundColor: Colors.blue[600],
                              foregroundColor: Colors.white,
                              padding: EdgeInsets.symmetric(
                                horizontal: screenWidth * 0.08,
                                vertical: screenWidth * 0.03,
                              ),
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(screenWidth * 0.025),
                              ),
                              elevation: 5,
                              textStyle: TextStyle(
                                fontSize: screenWidth * 0.045 > 18 ? 18 : screenWidth * 0.045,
                              ),
                            ),
                            child: const Text('Start Analysis'),
                          ),
                        ),
                        Padding(
                          padding: EdgeInsets.symmetric(vertical: padding),
                          child: ElevatedButton(
                            onPressed: widget.webSerial.isConnected
                                ? () {
                                    setState(() {
                                      _showManualCalibration = true;
                                    });
                                  }
                                : null,
                            style: ElevatedButton.styleFrom(
                              backgroundColor: Colors.blue[400],
                              foregroundColor: Colors.white,
                              padding: EdgeInsets.symmetric(
                                horizontal: screenWidth * 0.08,
                                vertical: screenWidth * 0.03,
                              ),
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(screenWidth * 0.025),
                              ),
                              elevation: 5,
                              textStyle: TextStyle(
                                fontSize: screenWidth * 0.045 > 18 ? 18 : screenWidth * 0.045,
                              ),
                            ),
                            child: const Text('Calibrate First'),
                          ),
                        ),
                        SizedBox(height: padding * 2), // Add extra space at the bottom
                      ],
                    ),
                  ),
                ),
              ),
              if (_showNotification)
                Positioned(
                  bottom: padding,
                  left: padding,
                  right: padding,
                  child: SlideTransition(
                    position: _notificationAnimation,
                    child: Card(
                      elevation: 5,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(screenWidth * 0.02),
                      ),
                      color: widget.webSerial.isConnected ? Colors.green : Colors.red,
                      child: Padding(
                        padding: EdgeInsets.all(padding * 0.5),
                        child: Text(
                          _notificationMessage,
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: screenWidth * 0.04 > 16 ? 16 : screenWidth * 0.04,
                          ),
                          textAlign: TextAlign.center,
                        ),
                      ),
                    ),
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }
}