import 'package:flutter/material.dart';
import '../widgets/aqua_sense_logo.dart';
import '../services/web_serial.dart';
import 'dart:convert';
import 'dart:async';
import 'dart:js_interop'; // For .toJS

class ResultScreen extends StatefulWidget {
  final WebSerial webSerial;

  const ResultScreen({super.key, required this.webSerial});

  @override
  ResultScreenState createState() => ResultScreenState();
}

class ResultScreenState extends State<ResultScreen> {
  double _pH = 7.2; // Default pH value
  String _status = 'Unknown';
  String? _errorMessage; // To display errors in UI
  late StreamSubscription<String> _dataSubscription;

  @override
  void initState() {
    super.initState();
    _fetchLatestPH();
    _dataSubscription = widget.webSerial.getDataStream().listen(
      (data) {
        if (data.contains("DATA:DATA:")) {
          // Extract JSON after "DATA:DATA:"
          try {
            // Find the start of JSON
            int jsonStart = data.indexOf('{"pH":');
            if (jsonStart == -1) {
              debugPrint('No valid JSON found in data: $data');
              setState(() {
                _errorMessage = 'Invalid data format';
              });
              return;
            }
            String jsonStr = data.substring(jsonStart).trim();
            // Attempt to parse JSON
            Map<String, dynamic> jsonData = jsonDecode(jsonStr);
            if (jsonData.containsKey('pH')) {
              double pHValue = double.parse(jsonData['pH'].toString());
              // Validate pH range (0 to 14)
              if (pHValue >= 0 && pHValue <= 14) {
                setState(() {
                  _pH = pHValue;
                  _status = (_pH >= 6.5 && _pH <= 8.5) ? 'Safe' : 'Unsafe';
                  _errorMessage = null; // Clear any previous error
                });
              } else {
                debugPrint('Invalid pH value: $pHValue');
                setState(() {
                  _errorMessage = 'Invalid pH value: $pHValue';
                });
              }
            } else {
              debugPrint('No pH key in JSON: $jsonStr');
              setState(() {
                _errorMessage = 'Missing pH data';
              });
            }
          } catch (error) {
            debugPrint('Error parsing pH data: $error, Raw data: $data');
            setState(() {
              _errorMessage = 'Error processing data';
            });
          }
        } else {
          debugPrint('Unexpected data format: $data');
        }
      },
      onError: (error) {
        debugPrint('WebSocket stream error: $error');
        setState(() {
          _errorMessage = 'Connection error';
        });
      },
    );
  }

  void _fetchLatestPH() {
    if (widget.webSerial.isConnected) {
      debugPrint('Fetching latest pH data at ${DateTime.now()}');
      widget.webSerial.socket!.send('START_ANALYSIS'.toJS);
    } else {
      debugPrint('WebSerial not connected');
      setState(() {
        _errorMessage = 'Device not connected';
      });
    }
  }

  @override
  void dispose() {
    _dataSubscription.cancel();
    super.dispose();
  }

  String _formatDateTime(DateTime dateTime) {
    final hour = dateTime.hour % 12 == 0 ? 12 : dateTime.hour % 12;
    final minute = dateTime.minute.toString().padLeft(2, '0');
    final period = dateTime.hour < 12 ? 'AM' : 'PM';
    return '${dateTime.month}/${dateTime.day}/${dateTime.year % 100} $hour:$minute $period';
  }

  void _showExplanationDialog(BuildContext context, String title, String explanation) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(title),
        content: Text(explanation),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Close'),
          ),
        ],
      ),
    );
  }

  void _startTestingAgain(BuildContext context) {
    Navigator.pop(context); // Return to HomePage
  }

  @override
  Widget build(BuildContext context) {
    final currentDateTime = DateTime.now();
    return Scaffold(
      body: Container(
        width: MediaQuery.of(context).size.width,
        height: MediaQuery.of(context).size.height,
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              Colors.blue[50]!,
              Colors.blue[100]!,
            ],
          ),
        ),
        child: SafeArea(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              const Padding(
                padding: EdgeInsets.symmetric(vertical: 20.0),
                child: AquaSenseLogo(),
              ),
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 20.0),
                child: Text(
                  'pH Analysis Result',
                  style: TextStyle(
                    fontSize: 24,
                    fontWeight: FontWeight.bold,
                    color: Colors.blue[800],
                  ),
                ),
              ),
              Card(
                elevation: 5,
                margin: const EdgeInsets.symmetric(horizontal: 20.0),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(15),
                ),
                child: Padding(
                  padding: const EdgeInsets.all(20.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        _formatDateTime(currentDateTime),
                        style: const TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                          color: Colors.black87,
                        ),
                      ),
                      const SizedBox(height: 10),
                      if (_errorMessage != null)
                        Text(
                          'Error: $_errorMessage',
                          style: TextStyle(
                            fontSize: 16,
                            color: Colors.red[700],
                          ),
                        )
                      else
                        Row(
                          children: [
                            Text(
                              'pH: ${_pH.toStringAsFixed(1)}',
                              style: const TextStyle(
                                fontSize: 16,
                                color: Colors.black87,
                              ),
                            ),
                            const SizedBox(width: 8),
                            IconButton(
                              icon: Icon(
                                Icons.info_outline,
                                size: 20,
                                color: Colors.blue[600],
                              ),
                              onPressed: () {
                                _showExplanationDialog(
                                  context,
                                  'pH Level',
                                  'The pH level measures the acidity or alkalinity of water. A pH between 6.5 and 8.5 is generally considered safe for drinking water. Your result of ${_pH.toStringAsFixed(1)} ${widget.webSerial.isConnected ? '' : '(mock data when disconnected)'} is ${widget.webSerial.isConnected && (_pH >= 6.5 && _pH <= 8.5) ? 'within the safe range.' : 'outside the safe range, which may affect water quality.'}',
                                );
                              },
                            ),
                          ],
                        ),
                      const SizedBox(height: 5),
                      if (_errorMessage == null)
                        Row(
                          children: [
                            Text(
                              'Status: $_status',
                              style: TextStyle(
                                fontSize: 16,
                                fontWeight: FontWeight.bold,
                                color: _status == 'Safe' ? Colors.green[700] : Colors.red[700],
                              ),
                            ),
                            const SizedBox(width: 8),
                            IconButton(
                              icon: Icon(
                                Icons.info_outline,
                                size: 20,
                                color: Colors.blue[600],
                              ),
                              onPressed: () {
                                _showExplanationDialog(
                                  context,
                                  'Status',
                                  'The status indicates water safety based on pH. "Safe" means the pH is between 6.5 and 8.5. "Unsafe" means the pH is outside this range, suggesting the water may not be suitable for drinking without treatment. ${widget.webSerial.isConnected ? '' : 'Note: This is mock data when no device is connected.'}',
                                );
                              },
                            ),
                          ],
                        ),
                    ],
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 20.0),
                child: ElevatedButton(
                  onPressed: () => _startTestingAgain(context),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.blue[600],
                    padding: const EdgeInsets.symmetric(
                      horizontal: 40,
                      vertical: 15,
                    ),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10),
                    ),
                    elevation: 5,
                  ),
                  child: const Text(
                    'Start Testing Again',
                    style: TextStyle(
                      fontSize: 18,
                      color: Colors.white,
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}