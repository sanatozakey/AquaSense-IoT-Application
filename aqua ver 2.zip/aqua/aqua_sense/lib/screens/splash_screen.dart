import 'package:flutter/material.dart';
import 'dart:math' as math;
import 'login_screen.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  _SplashScreenState createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _waveAnimation;
  late Animation<double> _textOpacity;
  late Animation<double> _textScale;
  late Animation<double> _rotateAnimation;
  bool _wavesActive = true;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 4),
    );

    _waveAnimation = Tween<double>(begin: 0.0, end: 2 * math.pi).animate(
      CurvedAnimation(
        parent: _controller,
        curve: Curves.linear,
      ),
    );

    _textOpacity = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(
        parent: _controller,
        curve: const Interval(0.75, 1.0, curve: Curves.easeIn),
      ),
    );

    _textScale = Tween<double>(begin: 0.8, end: 1.0).animate(
      CurvedAnimation(
        parent: _controller,
        curve: const Interval(0.75, 1.0, curve: Curves.easeOutBack),
      ),
    );

    _rotateAnimation = Tween<double>(begin: 0.0, end: 2 * math.pi).animate(
      CurvedAnimation(
        parent: _controller,
        curve: Curves.linear,
      ),
    );

    _controller.addStatusListener((status) {
      if (status == AnimationStatus.completed) {
        setState(() {
          _wavesActive = false;
        });
        _controller.stop();
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (context) => const LoginScreen()),
        );
      }
    });

    _controller.forward();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.blue[50],
      body: Center(
        child: AnimatedBuilder(
          animation: _controller,
          builder: (context, child) {
            return CustomPaint(
              size: const Size(250, 250),
              painter: WaterFlowPainter(
                waveProgress: _waveAnimation.value,
                rotateProgress: _rotateAnimation.value,
                wavesActive: _wavesActive,
              ),
              child: Container(
                width: 250,
                height: 250,
                alignment: Alignment.center,
                child: Opacity(
                  opacity: _textOpacity.value,
                  child: Transform.scale(
                    scale: _textScale.value,
                    child: const Text(
                      'AquaSense',
                      style: TextStyle(
                        fontSize: 32,
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                        shadows: [
                          Shadow(
                            blurRadius: 8.0,
                            color: Colors.black87,
                            offset: Offset(2, 2),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            );
          },
        ),
      ),
    );
  }
}

class WaterFlowPainter extends CustomPainter {
  final double waveProgress;
  final double rotateProgress;
  final bool wavesActive;

  WaterFlowPainter({
    required this.waveProgress,
    required this.rotateProgress,
    required this.wavesActive,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2);
    final radius = size.width / 2;
    final innerRadius = radius - 12;

    final bgPaint = Paint()
      ..color = Colors.white
      ..style = PaintingStyle.fill;
    canvas.drawCircle(center, innerRadius, bgPaint);

    if (wavesActive) {
      final wavePaint = Paint()
        ..shader = LinearGradient(
          colors: [
            Colors.blue[800]!.withOpacity(0.9),
            Colors.blue[900]!,
            Colors.blue[700]!.withOpacity(0.85),
            Colors.white.withOpacity(0.7),
          ],
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
        ).createShader(Rect.fromCircle(center: center, radius: radius))
        ..style = PaintingStyle.fill;

      for (int i = 0; i < 4; i++) {
        final path = Path();
        final waveHeight = 25.0 + i * 7.0;
        final waveSpeed = 1.2 + i * 0.3;
        for (double x = 0; x <= size.width; x += 1) {
          final y = center.dy +
              math.sin((x / size.width * math.pi) + waveProgress * waveSpeed + i) *
                  waveHeight +
              math.cos((x / size.width * math.pi / 2) + waveProgress * 0.7) * 8;
          if (x == 0) {
            path.moveTo(x, y);
          } else {
            path.lineTo(x, y);
          }
        }
        path.lineTo(size.width, size.height);
        path.lineTo(0, size.height);
        path.close();

        final clipPath = Path()
          ..addOval(Rect.fromCircle(center: center, radius: innerRadius));
        canvas.save();
        canvas.clipPath(clipPath);
        canvas.drawPath(path, wavePaint);
        canvas.restore();
      }
    } else {
      final calmPaint = Paint()
        ..color = Colors.blue[800]!.withOpacity(0.9);
      canvas.drawCircle(center, innerRadius, calmPaint);
    }

    final outlinePaint = Paint()
      ..color = Colors.blue[600]!
      ..style = PaintingStyle.stroke
      ..strokeWidth = 5.0
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 4.0);
    final arcRect = Rect.fromCircle(center: center, radius: radius);
    canvas.drawArc(
      arcRect,
      rotateProgress,
      2 * math.pi * 0.85,
      false,
      outlinePaint,
    );
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => true;
}