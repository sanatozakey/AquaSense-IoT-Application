import 'package:web/web.dart' as web;
import 'package:flutter/foundation.dart';
import 'dart:async';
import 'dart:js_interop';

class WebSerial {
  web.WebSocket? socket;
  final _dataStreamController = StreamController<String>.broadcast();
  final _connectionStatus = StreamController<bool>.broadcast();

  Stream<String> getDataStream() => _dataStreamController.stream;
  Stream<bool> getConnectionStatus() => _connectionStatus.stream;

  bool get isConnected => socket != null && socket!.readyState == web.WebSocket.OPEN;

  void connect() {
    socket = web.WebSocket('ws://localhost:8765');
    socket!.onOpen.listen((event) {
      debugPrint('WebSocket connected successfully at ${DateTime.now()}');
      _connectionStatus.add(true);
      // Send a test command to Arduino to verify connection
      verifySensorConnection();
    });

    socket!.onError.listen((event) {
      debugPrint('WebSocket error: $event at ${DateTime.now()}');
      _connectionStatus.add(false);
    });

    socket!.onClose.listen((event) {
      debugPrint('WebSocket closed: $event at ${DateTime.now()}');
      _connectionStatus.add(false);
    });

    socket!.onMessage.listen((message) {
      final data = message.data as String;
      debugPrint('Received message from Arduino: $data at ${DateTime.now()}');
      _dataStreamController.add(data);
    });
  }

  // Method to verify Arduino sensor connection by sending a test command
  void verifySensorConnection() {
    if (socket?.readyState == web.WebSocket.OPEN) {
      debugPrint('Sending test command to Arduino at ${DateTime.now()}');
      socket!.send('GET_PH'.toJS); // Convert String to JSAny using toJS
    } else {
      debugPrint('Cannot verify connection: WebSocket not open at ${DateTime.now()}');
    }
  }

  void disconnect() {
    socket?.close();
    _connectionStatus.add(false);
    debugPrint('WebSocket disconnected at ${DateTime.now()}');
  }

  // Cleanup to avoid memory leaks
  void dispose() {
    _dataStreamController.close();
    _connectionStatus.close();
    disconnect();
  }
}