const { SerialPort } = require('serialport');
const { ReadlineParser } = require('@serialport/parser-readline');
const { WebSocketServer } = require('ws');

// Serial port configuration
const SERIAL_PORT = 'COM3'; // Update this based on your system (e.g., COM3 on Windows)
const BAUD_RATE = 115200; // Match the Arduino sketch's baud rate

// Initialize SerialPort
const port = new SerialPort(
  { path: SERIAL_PORT, baudRate: BAUD_RATE },
  (err) => {
    if (err) {
      console.error('Serial port error:', err.message);
      process.exit(1);
    }
    console.log(`Connected to serial port ${SERIAL_PORT} at ${BAUD_RATE} baud`);
  }
);

// Set up parser to read lines from Serial
const parser = port.pipe(new ReadlineParser({ delimiter: '\n' }));

// Initialize WebSocket server
const wss = new WebSocketServer({ port: 8765 }, () => {
  console.log('WebSocket server running on ws://localhost:8765');
});

// Handle WebSocket connections
wss.on('connection', (ws) => {
  console.log('Client connected to WebSocket');

  // Forward Serial data to WebSocket clients
  parser.on('data', (data) => {
    const message = data.trim();
    if (message) {
      console.log('Received from Arduino:', message);
      ws.send(`DATA:${message}`); // Prefix with "DATA:" as expected by Flutter app
    }
  });

  // Handle messages from WebSocket clients (e.g., START_ANALYSIS, enterph, calph, exitph)
  ws.on('message', (message) => {
    const command = message.toString('utf-8').trim();
    if (command) {
      console.log('Received from client:', command);
      port.write(command + '\n', (err) => {
        if (err) {
          console.error('Error writing to serial port:', err.message);
        }
      });
    }
  });

  ws.on('close', () => {
    console.log('Client disconnected from WebSocket');
  });

  ws.on('error', (error) => {
    console.error('WebSocket error:', error.message);
  });
});

// Serial port error handling
port.on('error', (err) => {
  console.error('Serial port error:', err.message);
  process.exit(1);
});

port.on('close', () => {
  console.log('Serial port closed');
  process.exit(1);
});

// Handle uncaught exceptions
process.on('uncaughtException', (err) => {
  console.error('Uncaught exception:', err.message);
  process.exit(1);
});