package com.example.aqua_sense

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
